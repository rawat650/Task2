package com.example.myapplication

data class CardInfo(
    var title: String,
    var date: String
)
